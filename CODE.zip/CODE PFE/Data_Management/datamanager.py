import pandas as pd
import numpy as np


'''
    Function to load data from csv
'''
# Load data from csv
def load_data(filename, print_results=True):

    # Important parameters
    # sep : value seperator in input csv file (usually ,)
    # quotechar : string value identifier  (usually ")
    # decimal : how to interpret decimal values ? 
    #           French format : ,
    #           English format : .
    _df = pd.read_csv(filename, sep=',', quotechar='"', decimal=",")
    print(f"Read file {filename}")
    print("Data Frame Length ", len(_df))
    
    print("Data types :")
    for idx, c in enumerate(_df.columns):
        print(f"({idx}) {c} : {_df[c].dtype}")
        if _df[c].dtype == "object":
            print("Note : if a numeric data is read as 'object' type. It must be converted to numeric type.")
    
    if print_results is True : print(_df.head()) # show first few lines
    if print_results is True : _df.describe() # show dataframe summary

    print(" ")

    return _df

# Convert object data type to numeric type
def object_to_numeric(object_df_column):
    if object_df_column.dtype == 'object':    
        print(f"Converting {object_df_column.name} obect to numeric type.")
        return pd.to_numeric(object_df_column, errors='coerce') # Convert the column to numeric
    return object_df_column


# timestamp_column_name : name of time_stamp column with unit in seconds.
def get_sampling_frequency(df, timestamp_column_name):
    # Check if data is evenly sampled
    sampling_interval = np.round(df[timestamp_column_name].diff().dropna(), 5).unique() # the difference is rounded to 5 decimal point values to ignore minute variations.

    if len(sampling_interval) != 1:
        print("Variable sampling rate detected.")
        print("Data must be resampled before processing.")
        return np.inf

    else:
        print(f"Sampling interval : {sampling_interval[0]} sec")
    
        # NOTE : sampling_interval must be in secconds !
        # Otherwise the sampling freq will be incorrect.

        sampling_freq = 1/sampling_interval[0]
        print(f"Sampling freq : {sampling_freq} Hz")
        return sampling_freq


# Crop data sample (sample_start_t = window starting point, sample_duration = window size)
def get_data_sample(data, fs, sample_start_t, sample_duration, print_results=False): # fs in Hz; sample_start_t, sample_duration in sec
    # Choose duration and starting time of the sample
    sample_duration = sample_duration # in sec => 1 minute
    start_sec = sample_start_t # Start sample at this time instant
    
    sampling_interval = 1.0/fs # in sec

    # Determine Start and End indices for the sample
    start = int(start_sec / sampling_interval) if start_sec >= sampling_interval else 0
    stop = start + int(sample_duration / sampling_interval) if sample_duration >= sampling_interval else 0
    if stop > len(data) : 
        print("Sample duration is out of data range. Reducing sample size to fit data.")
        stop = len(data)
    if print_results is True : print(start, stop)

    # Crop sample data to extract the sample
    data_sample = data[start:stop] # Data
    return data_sample, start, stop

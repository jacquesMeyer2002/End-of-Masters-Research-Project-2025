# data science
import pandas as pd
import numpy as np

import functools 

def merge_datasets(datasets):
    merged_ds = pd.DataFrame()
    for ds in datasets:
        merged_ds = pd.concat([merged_ds,ds])
    return merged_ds

def insert_column_in_dataset(dataset, insert_column={}):
    for k,v in insert_column.items() : dataset[k] = v
    return dataset
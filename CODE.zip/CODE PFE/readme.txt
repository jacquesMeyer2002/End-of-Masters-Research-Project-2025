README - EDA and Machine Learning Notebook

Description

This Jupyter Notebook is structured into three main parts, each focusing on different aspects of signal processing, analysis, and machine learning:

1. Traitement du Signal (Signal Processing)

This section involves preprocessing and extracting relevant features from the Electrodermal Activity (EDA) signals. It includes:

Data Cleaning.

Splitting EDA into Phasic and Tonic Components: Decomposing the raw EDA signal to analyze its underlying characteristics.

Feature Extraction: Computing relevant statistical and physiological features for further analysis.

2. Example of Analysis

This section presents various visualizations and statistical analyses applied to the extracted EDA features. It focuses on:

Exploratory Data Analysis (EDA): Visualizing data trends and distributions.

Comparative Analysis: Evaluating EDA features across different groups (e.g., stressed, tired, not stressed).

Statistical Tests: Identifying significant differences between groups.

3. Machine Learning

The final section involves predictive modeling based on the extracted features. It includes:

Data Augmentation: Expanding the dataset to enhance model robustness.

Model Training: Implementing machine learning models to predict student grades based on features such as EDA, level of knowledge, and other contextual factors.

Data Confidentiality

The data used is confidential and belongs to the research center LyRIDS. Any unauthorized sharing, copying, or distribution of the data is strictly prohibited.

Acknowledgments

This work is part of a research study conducted at LyRIDS, and any use of the data or findings must be properly credited to the research team.
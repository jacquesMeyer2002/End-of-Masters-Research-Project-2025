# Electrodermal activity (EDA) is the umbrella term used 
# for defining autonomic changes in the electrical properties 
# of the skin. 
# The most widely studied property is the skin conductance. 
# The EDA complex includes both 
# - background tonic (skin conductance level: SCL) and 
# - rapid phasic components (Skin Conductance Responses: SCRs)
# that result from sympathetic neuronal activity.
#
# ***********************
# The typical units of electrodermal activity are 
# (i) the microsiemens (µS) or (ii) the micromho (µmho). 
# Both units are equivalent. So 1µS is equal to 1µmho.
# ***********************
# 
# 
# Skin conductance level (SCL) : 
# - Tonic level of electrical conductivity of skin
# - It relates to the slower acting components and background 
#   characteristics of the signal (the overall level, slow climbing,
#   slow declinations over time).
# - Changes in the SCL are thought to reflect general changes in autonomic arousal. 
# Skin conductance response (SCR) :
# - Phasic change in electrical conductivity of skin.
# - It refers to the faster changing elements of the signal.
# Non-specific SCR (NS-SCRs) :
#       SCRs that occur in the absence of an identifiable eliciting stimuli
# Frequency of NS-SCRs :
#       Rate of NS-SCRs that occur in the absence of identifiable stimuli
# Event-related SCR (ER-SCR) :
#       SCRs that can be attributed to a specific eliciting stimuli
#
# ***********************
# Crucially, it is important to be aware that the phasic SCR, which 
# often receives the most interest, only makes up a small proportion 
# of the overall EDA complex. 
# ***********************
#
#
# * Tonic SCL is constantly changing within an individual, 
#   and can differ markedly between them.
# * The SCL measure must be a relative difference across manipulations
#   (within the individual), and not based on the absolute numbers, which
#   might not be that informative.
# 
# * The most common SCR threshold was set at 0.05µS (approximately
#   the smallest shift visible on paper chart recorders). However, 
#   more recent advances in technology and precision have led to 
#   thresholds of 0.04µS, 0.03µS and 0.01µS becoming more common in 
#   the literature. Deflections in the signal that do not satisfy the
#   threshold criteria are not counted as SCRs or NS-SCRs.


# system imports
# import os
import sys

# data science
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt

# signal processing
from scipy import signal
from scipy import fftpack

# misc
parent_folders = ['..']
for folder in parent_folders:
    if sys.path.count(folder) < 1:
        sys.path.append(folder)
# from signal_processing import SignalTransform as ST
from Signal_Processing.signal_processing import SignalTransform as ST

# EDA data processing library
import neurokit2 as nk

' Calculate time stamps for a signal'
def get_t_sec(signal, sampling_freq):
    sampling_interval = 1.0/sampling_freq # in sec
    t_sec = np.arange(0,(len(signal)*sampling_interval), sampling_interval)
    return t_sec


class EdaAnalysis:
    
    DEFAULT_SCR_MIN_ALTITUDE = 0.015 # 0.3
    DEFAULT_PHASIC_TONIC_CUTOFF = 0.2 # 0.05 # 0.02 # 0.002
    
    ' Get Phasic and Tonic components from EDA_Raw signal '
    def split_phasic_tonic_signals(raw_eda, sampling_freq, time_stamp=None, phasic_cutoff=DEFAULT_PHASIC_TONIC_CUTOFF, show_signal_plot=False, show_freq_spectrum=False):
        
        # Seperate Phasic and Tonic components
        clean_eda = nk.eda_clean(raw_eda, sampling_freq)
        processed_eda = nk.eda_phasic(clean_eda, sampling_rate=sampling_freq, method='highpass', cutoff=phasic_cutoff)
        
        # Keep the raw data in the same dataframe
        processed_eda['EDA_Raw'] = raw_eda

        # Remove NaN
        check_columns = ['EDA_Tonic', 'EDA_Phasic']
        check_nan = pd.DataFrame(processed_eda[check_columns]).isnull().values.any()
        if check_nan : 
            print ("am in split_phasic_tonic_signals --> we are checking if EDA_Tonic and EDA_Phasic contain null values")
            processed_eda = processed_eda.dropna(subset=check_columns)
            processed_eda.reset_index(inplace=True)
            print("Removed NaN detected in processed_gsr. Remaing samlpes", len(processed_eda))

        # Add signal time stamps (in seconds)
        if time_stamp is not None:
            processed_eda.insert(0, 't_sec', time_stamp) # Insert 't_sec' as first column
        else :
            processed_eda.insert(0, 't_sec', get_t_sec(processed_eda,sampling_freq)) # Insert 't_sec' as first column

        # Plot Results
        if show_signal_plot: # Plot Time domain signals
            
            x_values = processed_eda['t_sec']/(60*60) # np.arange(0, len(processed_eda)/sampling_freq, 1/sampling_freq)/(60*60)

            plt.plot(x_values, processed_eda['EDA_Raw'], label='EDA')
            plt.plot(x_values, processed_eda['EDA_Phasic'], label='Phasic')
            plt.plot(x_values, processed_eda['EDA_Tonic'], label='Tonic')
            plt.xlabel('Hours')
            plt.legend()
            plt.show()        

        if show_freq_spectrum: # Plot Frequency domain analysis
            ST.fft(processed_eda['EDA_Raw'].values, sampling_freq, makeplot=True)
            ST.fft(processed_eda['EDA_Tonic'].values, sampling_freq, makeplot=True)
            ST.fft(processed_eda['EDA_Phasic'].values, sampling_freq, makeplot=True)
            plt.show()
        
        return processed_eda

    def get_phasic_peaks(phasic_component, sampling_freq, significant_peak_threshold = DEFAULT_SCR_MIN_ALTITUDE, relative_threshold = 0.1, print_summary=True, show_plot=False):
        
        # Find peaks
        _, peaks = nk.eda_peaks(phasic_component, sampling_rate=sampling_freq, method="neurokit", amplitude_min=relative_threshold)
        # print(len(phasic_component), len(peaks['SCR_Peaks']), peaks.keys())
        
        # All Peak Values
        # ERROR : This is SCR heigh not amplitude -> # peak_values = phasic_component.iloc[peaks['SCR_Peaks']]
        peak_values = peaks['SCR_Amplitude']

        if print_summary:
            print("significant amplitude threshold", significant_peak_threshold)
        
        # Identify significant peaks
        # * Commonly used significant peak thresholds : 0.05, 0.03, 0.3, 0.1, 0.005
        MASK_SIGNIFICANT_PEAKS = peak_values > significant_peak_threshold
        significant_peaks_index = peaks['SCR_Peaks'][MASK_SIGNIFICANT_PEAKS]
        insignificant_peaks_index = peaks['SCR_Peaks'][~MASK_SIGNIFICANT_PEAKS]

        # Add significant peaks to df
        res_significant_peaks = pd.DataFrame()
        res_significant_peaks['EDA_Phasic'] = phasic_component
        res_significant_peaks['SCR_Peaks'] = 0
        res_significant_peaks.loc[significant_peaks_index, 'SCR_Peaks'] = 1
        # print(len(res_significant_peaks[significant_peaks_index]), res_significant_peaks[significant_peaks_index])

        # Add significant peak Amplitudes to df
        res_significant_peaks['SCR_Amplitude'] = 0.0
        res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude'] = peaks['SCR_Amplitude'][MASK_SIGNIFICANT_PEAKS]
        # print(len(res_significant_peaks[processed_eda['SCR_Amplitude']>0]),res_significant_peaks[res_significant_peaks['SCR_Amplitude']>0])

        # Add significant peak Durations to df
        res_significant_peaks['SCR_RiseTime'] = 0.0
        res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime'] = peaks['SCR_RiseTime'][MASK_SIGNIFICANT_PEAKS]
        # print(len(res_significant_peaks[res_significant_peaks['SCR_RiseTime']>0]),res_significant_peaks[res_significant_peaks['SCR_RiseTime']>0])

        # Replace NaN by 0
        check_columns = ['SCR_Amplitude', 'SCR_Peaks', 'SCR_RiseTime']
        check_nan = pd.DataFrame(res_significant_peaks[check_columns]).isnull().values.any()

        if check_nan:
            print ("am in get_phasic_peaks --> check_columns = ['SCR_Amplitude', 'SCR_Peaks', 'SCR_RiseTime'] ")
            res_significant_peaks[check_columns] = res_significant_peaks[check_columns].fillna(0)
            print("--------------  Replacing NaN (by 0) detected in res_significant_peaks", check_nan)
            check_nan = pd.DataFrame(res_significant_peaks[check_columns]).isnull().values.any()
            if check_nan:
                print("***************** NaN not removed. ", check_nan)
                print(res_significant_peaks[check_columns].to_markdown())

        
        if print_summary:
            print('Peaks count : All->', len(peak_values), 'Significant->', len(significant_peaks_index))
            
            # Peak Amplitudes Summary
            # print('All Peak Amplitudes Summary: ',
            #     'median ', np.median(peaks['SCR_Amplitude']), 
            #     'mean', np.mean(peaks['SCR_Amplitude']), 
            #     'max', np.max(peaks['SCR_Amplitude']), 
            #     'min', np.min(peaks['SCR_Amplitude']))

            # Significant Peak Amplitudes and Durations
            print('Significant Peak Amplitudes Summary:',
                'mean', np.mean(res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude']),
                'sum', np.sum(res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude']),
                'SD', np.std(res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude']),
                'max', np.max(res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude']), 
                'min', np.min(res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude']))
            print('Significant Peak Durations Summary:',
                'mean', np.mean(res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime']),
                'sum', np.sum(res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime']),
                'SD', np.std(res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime']),
                'max', np.max(res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime']),
                'min', np.min(res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime']))
        
        if show_plot:
            t_ref = get_t_sec(res_significant_peaks,sampling_freq)

            plt.plot(t_ref, res_significant_peaks['EDA_Phasic'], label="Phasic")
            plt.plot(t_ref[significant_peaks_index], res_significant_peaks.loc[significant_peaks_index, 'EDA_Phasic'], 'o', label="Peaks")
            plt.vlines(t_ref[significant_peaks_index], ymin=res_significant_peaks.loc[significant_peaks_index, 'EDA_Phasic']-res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude'], ymax=res_significant_peaks.loc[significant_peaks_index, 'EDA_Phasic'], color='red', label="Amplitude")
            plt.hlines(res_significant_peaks.loc[significant_peaks_index, 'EDA_Phasic']-res_significant_peaks.loc[significant_peaks_index, 'SCR_Amplitude'], xmin=t_ref[significant_peaks_index]-res_significant_peaks.loc[significant_peaks_index, 'SCR_RiseTime'], xmax=t_ref[significant_peaks_index], color='green', label="Rise_Time")
            plt.legend()
            plt.show()

        # Return only peaks and their characteristics
        res_significant_peaks.drop(columns=['EDA_Phasic'], inplace=True)

        return res_significant_peaks
            


    # '''''''''''''''''''''''''''''
    # Function for EDA Signal Pre-processing
    # Data cleaning and preparation to extract features
    # '''''''''''''''''''''''''''''
    # def process_data(EDA_data, fs, printt_warning=False):
    #     processed_EDA, info = nk.eda_process(EDA_data, sampling_rate=fs)
        
    #     # Applying the method
    #     check_columns = ['SCR_Amplitude', 'SCR_Peaks', 'SCR_RiseTime']
        
    #     check_nan = pd.DataFrame(processed_EDA[check_columns]).isnull().values.any()
    #     # check_nan = signal['RSP_Rate'].isnull().values.any()
    #     if check_nan : 
    #         processed_EDA = processed_EDA.dropna(subset=check_columns)
    #         if printt_warning : print("Removing the NaN detected in processed_EDA", check_nan, "remaing", len(processed_EDA))
    #         check_nan = pd.DataFrame(processed_EDA[check_columns]).isnull().values.any()
    #         if check_nan : 
    #             print("NaN not removed. ", check_nan)
    #             print(processed_EDA[check_columns].to_markdown())
    
    #     return processed_EDA

    '''''''''''''''''''''''''''''
    Function for EDA Feature Extraction
    '''''''''''''''''''''''''''''
    def extract_features(processed_eda, sampling_freq, show_plot=False, print_results=True):
        eda_features = {}

        eda_features['SCR_Peak_Count'] = processed_eda['SCR_Peaks'].sum()
        eda_features['SCR_Peak_Mean_Amplitude'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_Amplitude'].mean()
        eda_features['SCR_Peak_Max_Amplitude'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_Amplitude'].max()
        eda_features['SCR_Peak_Min_Amplitude'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_Amplitude'].min()
        eda_features['SCR_Peak_STD_Amplitude'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_Amplitude'].std()
        eda_features['SCR_Peak_Sum_Amplitude'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_Amplitude'].sum()
        eda_features['SCR_Peak_Mean_Risetime'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_RiseTime'].mean()
        eda_features['SCR_Peak_Max_Risetime'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_RiseTime'].max()
        eda_features['SCR_Peak_Min_Risetime'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_RiseTime'].min()
        eda_features['SCR_Peak_STD_Risetime'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_RiseTime'].std()
        eda_features['SCR_Peak_Sum_Risetime'] = processed_eda[processed_eda['SCR_Peaks']>0]['SCR_RiseTime'].sum()
        eda_features['SCR_AUC'] = np.trapz(np.abs(processed_eda['EDA_Phasic']), processed_eda['t_sec'])
        eda_features['SCR_MEAN'] = processed_eda['EDA_Phasic'].mean()
        eda_features['SCR_STD'] = processed_eda['EDA_Phasic'].std()
        if eda_features['SCR_Peak_Mean_Risetime'] != 0:
            eda_features['SCR_Peak_Amplitude_Risetime_Ratio'] = eda_features['SCR_Peak_Mean_Amplitude'] / eda_features['SCR_Peak_Mean_Risetime']
        else:
            eda_features['SCR_Peak_Amplitude_Risetime_Ratio'] = float('inf')
        # Tonic Features
        eda_features['SCL_Mean'] = processed_eda['EDA_Tonic'].mean()
        eda_features['SCL_STD'] = processed_eda['EDA_Tonic'].std()
        eda_features['SCL_Var'] = processed_eda['EDA_Tonic'].var()
        eda_features['SCL_Max'] = processed_eda['EDA_Tonic'].max()
        eda_features['SCL_Min'] = processed_eda['EDA_Tonic'].min()

        tonic_var = np.diff(processed_eda["EDA_Tonic"])
        tonic_var = np.append(tonic_var, tonic_var[-1])
        tonic_var_mean = tonic_var.mean()
        eda_features['tonic_var'] = tonic_var_mean

        '''
        def compute_changes(curve):
            _diff = np.diff(curve)
            ic=len(_diff[_diff>0])
            dc=len(_diff[_diff<0])
            tc = ic + dc
            return (ic / tc) * 100, (dc / tc) * 100
        ip, dp = compute_changes(processed_eda['EDA_Tonic'])
        
        eda_features['SCL_Inc_Percentage'] = ip
        eda_features['SCL_Dec_Percentage'] = dp
        '''
        if print_results:
            print("Phasic Features:")
            # Phasic Features
            print("Phasic Peak count", eda_features['SCR_Peak_Count'])
            print("Phasic Mean Amplitude", eda_features['SCR_Peak_Mean_Amplitude'])
            print("Phasic Max Amplitude", eda_features['SCR_Peak_Max_Amplitude'])
            print("Phasic Min Amplitude", eda_features['SCR_Peak_Min_Amplitude'])
            print("Phasic STD Amplitude", eda_features['SCR_Peak_STD_Amplitude'])
            print("Phasic Sum Amplitude", eda_features['SCR_Peak_Sum_Amplitude'])
            print("Phasic Mean RiseTime", eda_features['SCR_Peak_Mean_Risetime'])
            print("Phasic Max RiseTime", eda_features['SCR_Peak_Max_Risetime'])
            print("Phasic Min RiseTime", eda_features['SCR_Peak_Min_Risetime'])
            print("Phasic STD RiseTime", eda_features['SCR_Peak_STD_Risetime'])
            print("Phasic Sum RiseTime", eda_features['SCR_Peak_Sum_Risetime'])
            print("Phasic AUC", eda_features['SCR_AUC'])

            print("Tonic Features:")
            # Tonic Features
            print("Tonic Mean", eda_features['SCL_Mean'])
            print("Tonic STD", eda_features['SCL_STD'])
            print("Tonic Variance", eda_features['SCL_Var'])
            print("Tonic Max", eda_features['SCL_Max'])
            print("Tonic Min", eda_features['SCL_Min'])

        
        return eda_features
    
    '''''''''''''''''''''''''''''
    Functions for Complete Pipeline Processing
    '''''''''''''''''''''''''''''
    def get_features(raw_eda, sampling_freq, time_stamp=None, feature_list=[], phasic_cutoff=DEFAULT_PHASIC_TONIC_CUTOFF, significant_peak_threshold = DEFAULT_SCR_MIN_ALTITUDE, show_plot=False, print_results=True):
        
        # Pre-processing, Peak detection and feature extraction
        
        # Seperate Tonic and Phasic components
        split_eda = EdaAnalysis.split_phasic_tonic_signals(raw_eda, sampling_freq=sampling_freq, time_stamp=time_stamp, show_signal_plot=show_plot, show_freq_spectrum=False)
        # print(split_eda.columns)

        # Find peaks
        peaks = EdaAnalysis.get_phasic_peaks(split_eda['EDA_Phasic'], sampling_freq=sampling_freq, print_summary=print_results, show_plot=show_plot)

        # Concatenate the DataFrames along the columns (axis=1)
        processed_eda = pd.concat([split_eda, peaks], axis=1)
        # print(processed_eda)

        # Feature Extraction
        # All features
        features = EdaAnalysis.extract_features(processed_eda, sampling_freq=sampling_freq, show_plot=show_plot, print_results=print_results)
        # print(features)
        
        # Filter features
        if len(feature_list) == 0 : # All Features
            return features
        else :  # Requested Features
            
            # Print invalid Requested Features
            invalid_features = np.setdiff1d(feature_list, list(features.keys()))
            if len(invalid_features) > 0 : print("Invalid Features : ",invalid_features)
            
            # Return (valid) Requested Features
            valid_features = np.intersect1d(feature_list, list(features.keys()))
            ret_features = {}
            for f in valid_features :
                ret_features[f] = features[f]

            return ret_features



        

    '''''''''''''''''''''''''''''
    def get_features(EDA_Phaic, EDA_Tonic, t_sec, sampling_freq, time_stamp=None, feature_list=[], phasic_cutoff=DEFAULT_PHASIC_TONIC_CUTOFF, significant_peak_threshold = DEFAULT_SCR_MIN_ALTITUDE, show_plot=False, print_results=True):
        
        # Pre-processing, Peak detection and feature extraction
        # Seperate Tonic and Phasic components
        #split_eda = EdaAnalysis.split_phasic_tonic_signals(raw_eda, sampling_freq=sampling_freq, time_stamp=time_stamp, show_signal_plot=show_plot, show_freq_spectrum=False,phasic_cutoff=phasic_cutoff)
        #print(split_eda.columns)

        # Find peaks
        peaks = EdaAnalysis.get_phasic_peaks(EDA_Phaic, sampling_freq=sampling_freq, print_summary=print_results, show_plot=show_plot)

        # Concatenate the DataFrames along the columns (axis=1)
        processed_eda = pd.concat([EDA_Phaic, EDA_Tonic, t_sec, peaks], axis=1)
        # print(processed_eda)

        # Feature Extraction
        # All features
        features = EdaAnalysis.extract_features(processed_eda, sampling_freq=sampling_freq, show_plot=show_plot, print_results=print_results)
        #print(features)
                
        # Filter features
        if len(feature_list) == 0 : # All Features
            return features
        else :  # Requested Features
            
            # Print invalid Requested Features
            invalid_features = np.setdiff1d(feature_list, list(features.keys()))
            if len(invalid_features) > 0 : print("Invalid Features : ",invalid_features)
            
            # Return (valid) Requested Features
            valid_features = np.intersect1d(feature_list, list(features.keys()))
            ret_features = {}
            for f in valid_features :
                ret_features[f] = features[f]

            return ret_features
    '''''''''''''''''''''''''''''

